/* Include the JDBC Driver for mysql in ecllipse mysql-connector-java-5.1.25-bin which is included in the zip file
   also keep the data files in the same folder.
*/
/* Praveen Kumar Vanga : 1000916466
   Raghuveer Yerneni:    1000918627
*/

import java.io.BufferedReader;
import java.io.FileReader;
import java.sql.*;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class MysqlTest {
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";  
	static final String DB_URL = "jdbc:mysql://localhost/COMPANY";

	static final String USER = "root";
	static final String PASS = "vanga";

	public static void main(String[] args) {
		Connection conn = null;
		Statement stmt = null;
		try{
			Class.forName("com.mysql.jdbc.Driver");

			System.out.println("Connecting to a selected database...");
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			System.out.println("Connected database successfully...");

			System.out.println("Creating statement...");
			stmt = conn.createStatement();

			BufferedReader br = null;
			String sCurrentLine;

			br = new BufferedReader(new FileReader("E:\\EMPLOYEE.txt"));
			Map<String, Object> mp=new HashMap<String, Object>();
			

			while ((sCurrentLine = br.readLine()) != null) {

				System.out.println(sCurrentLine);

				int last_occurence_index = sCurrentLine.lastIndexOf(',');
				String str1 = sCurrentLine.substring(0, last_occurence_index);
				String str2 = ", null";
				String str3 = sCurrentLine.substring(last_occurence_index + 2);
				int Department_num = Integer.parseInt(str3);

				int ssn_occurence1 = nthOccurrence(sCurrentLine, ',' , 2 );
				int ssn_occurence2 = nthOccurrence(sCurrentLine, ',' , 3 );

				String ssn_crude = sCurrentLine.substring(ssn_occurence1, ssn_occurence2);

				ssn_occurence1 = nthOccurrence(ssn_crude, '\'', 0 );
				ssn_occurence2 = nthOccurrence(ssn_crude, '\'', 1 );

				String ssn = ssn_crude.substring(ssn_occurence1 + 1, ssn_occurence2);

				System.out.println(ssn);
				System.out.println(str1+str2);
				System.out.println(str3);

				int date_occurence_1  = nthOccurrence(sCurrentLine, ',', 3 );
				int date_occurence_2 =  nthOccurrence(sCurrentLine, ',', 4 );

				String date_crude = sCurrentLine.substring(date_occurence_1, date_occurence_2);

				date_occurence_1 = nthOccurrence(ssn_crude, '\'', 0 );
				date_occurence_2 = nthOccurrence(ssn_crude, '\'', 1 );

				String date = date_crude.substring(date_occurence_1 + 1, date_occurence_2);

				String mysql_date = "str_to_date('" + date + "', '%d-%b-%Y')";

				System.out.println(mysql_date);

				date_occurence_1  = nthOccurrence(sCurrentLine, ',', 3 );
				date_occurence_2 =  nthOccurrence(sCurrentLine, ',', 4 );

				String str1_1 = str1.substring(0, date_occurence_1 + 1);
				String str1_2 = str1.substring(date_occurence_2);

				System.out.println(str1_1);
				System.out.println(str1_2);
				
		        mp.put(ssn, new Integer(Department_num));

				str1 = str1_1 + " " + mysql_date + str1_2;	
				System.out.println(str1);
				String sql = "INSERT INTO employee VALUES (" + str1 + str2 + ")";
				System.out.println(sql);
				stmt.executeUpdate(sql);
			}
			
			br = new BufferedReader(new FileReader("E:\\DEPARTMENT.txt"));
			while ((sCurrentLine = br.readLine()) != null) {

				System.out.println(sCurrentLine);

				int last_occurence_index = sCurrentLine.lastIndexOf(',');
				String str1 = sCurrentLine.substring(0, last_occurence_index + 1);
				String str2 = sCurrentLine.substring(last_occurence_index+1);
				
				System.out.println(str1);
				System.out.println(str2);
				
				int date_occurence_1 = nthOccurrence(str2, '\'', 0 );
				int date_occurence_2 = nthOccurrence(str2, '\'', 1 );
				
				String date = str2.substring(date_occurence_1 + 1, date_occurence_2);
				
				String mysql_date = "str_to_date('" + date + "', '%d-%b-%Y')";
				System.out.println(mysql_date);
				String sql = "INSERT INTO DEPARTMENT VALUES (" + str1 + " " +  mysql_date + ")";
				System.out.println(sql);
				stmt.executeUpdate(sql);
			} 
			
			br = new BufferedReader(new FileReader("E:\\PROJECT.txt"));
			while ((sCurrentLine = br.readLine()) != null) {

				System.out.println(sCurrentLine);
				String sql = "INSERT INTO PROJECT VALUES (" + sCurrentLine + ")";
				System.out.println(sql);
				stmt.executeUpdate(sql);
			}
			
			br = new BufferedReader(new FileReader("E:\\WORKS_ON.txt"));
			while ((sCurrentLine = br.readLine()) != null) {

				System.out.println(sCurrentLine);
				String sql = "INSERT INTO WORKS_ON VALUES (" + sCurrentLine + ")";
				System.out.println(sql);
				stmt.executeUpdate(sql);
			}
			

			br = new BufferedReader(new FileReader("E:\\DEPT_LOCATIONS.txt"));
			while ((sCurrentLine = br.readLine()) != null) {

				System.out.println(sCurrentLine);
				String sql = "INSERT INTO DEPT_LOCATIONS VALUES (" + sCurrentLine + ")";
				System.out.println(sql);
				stmt.executeUpdate(sql);
			}
			
			Set s=mp.entrySet();
	        Iterator it=s.iterator();
			
	        while(it.hasNext())
	        {
	            Map.Entry m =(Map.Entry)it.next();
	            int value=(Integer)m.getValue();	            
	            String key=(String)m.getKey();
	            
	            String sql = "SELECT Dname FROM DEPARTMENT WHERE DNUMBER = " + value; 
	            ResultSet rs = stmt.executeQuery(sql);
	            String Dname = "";
	            while(rs.next()){
	                Dname = rs.getString("Dname");
	                System.out.println("Dname :" + Dname);
	             }
	             rs.close();
	             
	             if(Dname != "")
	             {
	            	sql = "UPDATE EMPLOYEE SET DNO = " + value + " WHERE SSN = " + key;
	            	System.out.println(sql);
	            	stmt.executeUpdate(sql);
	             }
	             else
	             {
	            	 sql = "DELETE FROM EMPLOYEE WHERE SSN = " + key;
	            	 System.out.println(sql);
	            	 stmt.executeUpdate(sql);
	             }
	             
	        }		
		}catch(SQLException se){
			se.printStackTrace();
		}catch(Exception e){
			e.printStackTrace();
		}finally{
			try{
				if(stmt!=null)
					conn.close();
			}catch(SQLException se){
			}
			try{
				if(conn!=null)
					conn.close();
			}catch(SQLException se){
				se.printStackTrace();
			}
		}
	}
	public static int nthOccurrence(String str, char c, int n) {
		int pos = str.indexOf(c, 0);
		while (n-- > 0 && pos != -1)
			pos = str.indexOf(c, pos+1);
		return pos;
	}
}